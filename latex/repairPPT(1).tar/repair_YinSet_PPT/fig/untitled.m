

figure
% 
% a = [0 -1 0];
% b = [1 0 0];
% c = [0 1 0];
% fill3(a, b, c, [1 0 0]); hold on
% 
% 
% a = [0 1 0];
% b = [1 1 0];
% c = [0 1 0];
% fill3(a, b, c, [1 1 0]); hold on
% 
% 
% a = [0 -1 0];
% b = [1 0 0];
% c = [0 0 0];
% fill3(a, b, c, [0 1 0]); hold on
%      
% 
% a = [0 1 0];
% b = [1 0 0];
% c = [0 0 0];
% fill3(a, b, c, [0 0 1]); hold on
a = [0.9 0.9 19];
b = [0 10 0];
fill(a, b, [0 1 0]); hold on
a = [19 0.9 19];
b = [10 10 0];
fill(a, b, [0 1 0]); hold on
a = [0 0 3];
b = [0 1 0];
fill(a, b, [1 0 0]); hold on
a = [3 0 3];
b = [1 1 0];
fill(a, b, [1 0 0]); hold on